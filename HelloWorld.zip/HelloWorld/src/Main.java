public class Main {
    public static void main(String[] args) {


        Animal ani2 = new Animal();



        Animal animal = new Animal("Duncan", 2);

        Rabbit rabbit = new Rabbit();
        Rabbit rabbit2= new Rabbit("Donald", "White");

        Rabbit rabbit3= new Rabbit("Damien", "Mottled", 12);


        rabbit.setAge(-100);

        System.out.println(Rabbit.getCount());
        System.out.println(rabbit.getName());
        System.out.println(rabbit2.toString());
        System.out.println(rabbit3.toString());

        System.out.println(animal.toString());
        System.out.println(ani2.toString());




    }


}